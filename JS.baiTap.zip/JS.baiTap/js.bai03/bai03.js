/*Bài tập 03 Quy đổi tiền

1.Đầu vào:
+ 1USD = 23.500VND

2. Xử lý
+ Quy đổi USD sang VND

3. Đầu ra
+ Xuất kết quả VND */

var usd, unit, result;
usd=23500
unit="VND"
result=(2*usd)+unit;
console.log(result);

