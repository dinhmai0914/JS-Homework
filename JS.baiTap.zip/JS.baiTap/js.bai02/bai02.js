/* Bài 02: Tính trung bình 5 số thực
1. Đầu vào:
+ 5 số thực

2.Xử lý
+ Tổng 5 số thực chia 5

3.Đầu ra
+Xuất kết quả */


var num1, num2, num3, num4, num5,avarg;
num1=10;
num2=20;
num3=30;
num4=40;
num5=50;
avarg=(num1+num2+num3+num4+num5)/5;
console.log(avarg);