/* Bài 04 Tính diện tích, chu vi hình chữ nhật

1.Đầu vào
+ Chiều dài, chiều rộng

2. Xử lý
+ Diện tích HCN = dài x rộng
+ Chu vi HCN = (dài + rộng) x 2

3. Đầu ra
+ Kết quả diện tích và chu vi HCN */

var dai, rong, chuVi, dienTich;
dai=4;
rong=5;
chuVi=(dai+rong)*2;
dienTich=dai*rong;
console.log(chuVi);
console.log(dienTich);