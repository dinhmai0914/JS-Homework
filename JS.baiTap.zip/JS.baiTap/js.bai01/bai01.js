/*Bai 1: Tính tiền lương nhân viên

1. Đầu vào:
+Lương 1 ngày: 100.000
+Số ngày làm

2.Xử lý
+Lương = lương 1 ngày x số ngày làm

3.Đầu ra
+Lương theo số ngày làm*/


var dayWork, salaryADay,result,unit;
salaryADay=100000
dayWork=22
unit=" VND"
result=(salaryADay*dayWork)+unit;
console.log(result);


